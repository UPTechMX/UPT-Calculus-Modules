# -*- coding: utf-8 -*-
import sys
import os
import multiprocessing
import threading
import _thread as thread
import time
import gc
from random import randint
import json
import math
from plup.indicators.Indicator import Indicator
from plup.Helpers.Vacuum import vacuum
from plup.Helpers.LogEvents import LogEvents

# pathname = os.path.dirname(os.path.realpath(__file__))
# __django_path = os.path.abspath(pathname+"/../../../")
# sys.path.insert(1, __django_path)
# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "UP.settings")
# import django
# django.setup()
from django.db import transaction,connection
from plup.models import assumptions

class Module:
    def __init__(self, user, scenario, extra_dict_arguments=None):
        self.__user = user
        self.__scenario = scenario

    def run(self):
        try:
            self.__Indicator = Indicator(self.__user)
            amenity_classes=self.__getAmenitiesClassess()
            # amenity_classes_set=assumptions.objects.filter(category='telecom_infrastructure').values("name")
            # amenity_classes=[]
            # for amenity in list(amenity_classes_set):
            #     amenity_classes.append(amenity["name"])
            # amenity_classes = ["telecom"]
            amenity_classes_array="'{"+",".join(amenity_classes)+"}'"

            risk_classes=self.__getRiskClassess()
            # risk_classes_set=assumptions.objects.filter(category='risk').values("name")
            # risk_classes=[]
            # for risk in list(risk_classes_set):
            #     risk_classes.append(risk["name"])
            #risk_classes = ["flood"]
            risk_classes_array="'{"+",".join(risk_classes)+"}'"
            error = True
            count = 0
            while error and count < 3:
                self.__Indicator = Indicator(self.__user)
                db = self.__Indicator.get_up_calculator_connection()
                try:
                    query = """
                        select urbper_indicator_telecom_infrastructure_in_risk({scenario},'telecom_risk'::varchar(10),{amenity_class},{risk_classes})
                        """.format(
                            scenario=self.__scenario, 
                            amenity_class=amenity_classes_array,
                            risk_classes=risk_classes_array
                        )
                    LogEvents(
                        "telecomunications infrastructure in risk",
                        "telecomunications infrastructure in risk module started: " + query,
                        self.__scenario,
                        self.__user
                    )
                    with transaction.atomic():
                        db.execute(query)
                except Exception as e:
                    error = True
                    count += 1
                    time.sleep(randint(1, 3))
                    db.close()
                    LogEvents(
                        "telecomunications infrastructure in risk",
                        "telecomunications infrastructure in risk module failed " +
                        str(count) + ": " + str(e),
                        self.__scenario,
                        self.__user
                    )
                else:
                    error = False
                    db.close()
                    LogEvents(
                        "telecomunications infrastructure in risk",
                        "telecomunications infrastructure in risk module finished",
                        self.__scenario,
                        self.__user
                    )
        except Exception as e:
            LogEvents(
                "telecomunications infrastructure in risk",
                "unknown error " +
                str(e),
                self.__scenario,
                self.__user
            )
    
    def __getRiskClassess(self):
        try:
            error = True
            count = 0
            while error and count < 3:
                try:
                    with connection.cursor() as cursor:
                        query="""select distinct risk.fclass from risk
                            inner join classification on classification.name=risk.fclass
                            where classification.category='risk'
                            and classification.fclass='risk'
                            and risk.scenario_id={}""".format(self.__scenario)                        
                        LogEvents(
                            "risk fclasses",
                            "risk fclasses started: " + query,
                            self.__scenario,
                            self.__user
                        )
                        cursor.execute(query)

                        results_set=[list(row)[0] for row in cursor.fetchall()]
                        
                    results=results_set
                except Exception as e:
                    error = True
                    count += 1
                    time.sleep(randint(1, 3))
                    LogEvents(
                        "risk fclasses",
                        "risk fclasses failed " +
                        str(count) + ": " + str(e),
                        self.__scenario,
                        self.__user
                    )
                else:
                    error = False
                    LogEvents(
                        "risk fclasses",
                        "risk fclasses finished",
                        self.__scenario,
                        self.__user
                    )
                    return results
        except Exception as e:
            LogEvents(
                "risk fclasses",
                "unknown error " + str(e),
                self.__scenario,
                self.__user
            )

    def __getAmenitiesClassess(self):
        try:
            error = True
            count = 0
            while error and count < 3:
                try:
                    with connection.cursor() as cursor:
                        query="""
                            select distinct amenities.fclass from amenities
                            inner join classification on classification.name=amenities.fclass
                            where classification.category='amenities'
                            and classification.fclass='telecom_infrastructure'
                            and amenities.scenario_id={}""".format(self.__scenario)                        
                        LogEvents(
                            "amenities fclasses",
                            "amenities fclasses started: " + query,
                            self.__scenario,
                            self.__user
                        )
                        cursor.execute(query)

                        results_set=[list(row)[0] for row in cursor.fetchall()]
                        
                    results=results_set
                except Exception as e:
                    error = True
                    count += 1
                    time.sleep(randint(1, 3))
                    LogEvents(
                        "amenities fclasses",
                        "amenities fclasses failed " +
                        str(count) + ": " + str(e),
                        self.__scenario,
                        self.__user
                    )
                else:
                    error = False
                    LogEvents(
                        "amenities fclasses",
                        "amenities fclasses finished",
                        self.__scenario,
                        self.__user
                    )
                    return results
        except Exception as e:
            LogEvents(
                "amenities fclasses",
                "unknown error " + str(e),
                self.__scenario,
                self.__user
            )
    
    